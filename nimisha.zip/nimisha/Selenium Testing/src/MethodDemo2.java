
public class MethodDemo2 {
	
	public String getuserData()
	{
		System.out.println("hellow peter");
		return ("abhilash");
	}
	

}
